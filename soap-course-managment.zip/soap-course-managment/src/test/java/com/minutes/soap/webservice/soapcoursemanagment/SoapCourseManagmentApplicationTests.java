package com.minutes.soap.webservice.soapcoursemanagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapCourseManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
