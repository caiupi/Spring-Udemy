package com.minutes.soap.webservice.soapcoursemanagment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapCourseManagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapCourseManagmentApplication.class, args);
	}

}
